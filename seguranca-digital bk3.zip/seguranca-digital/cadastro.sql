-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 22/06/2025 às 05:42
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cadastro`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `alunos`
--

CREATE TABLE `alunos` (
  `id` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `telefone` varchar(11) DEFAULT NULL,
  `senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `alunos`
--

INSERT INTO `alunos` (`id`, `user_name`, `nome`, `email`, `telefone`, `senha`) VALUES
(1, 'eueueu12', 'ma aaa', 'ma@gm.com', '21234434565', '$2y$10$48Pr4JYbGqForc744zqSSut7daYo5.Axp1MjQYtrfn6xht4n04WIu'),
(2, 'eueueu1', 'ma th', 'matheus@m.com', '21232544354', '$2y$10$3ekcxhYRdrBOyuBcvu2q6eLAl3hrvmOkKGYDu2zy9OPq3Qajo.CMC'),
(3, 'jesuscristo', 'jesus cristo', 'jesuscristo@g.com', '23293894778', '$2y$10$cR6joATlc03ImEwxsybmqOvqukAEH.xyq0uzhrsv1Z7Fxj5q1CJxS'),
(4, 'fwgrgergr', 'ewfef efewfew fvergergr', 'dfew@gm.com', '23456787654', '$2y$10$6clijhB.xvEK7PNozPEkGeBbl1rKM.wjRYQ4jPFH47ClKJoxNBRiO'),
(5, 'euadm', 'ma th', 'math@gm.com', '21121212121', 'Matheus19@'),
(6, 'Lulu123', 'Luiza Solza', 'lulu@gmail.com', '21111111111', '$2y$10$kP3f9UZr83Pf4vMxt3/aw.8YnXlhjfnTw8rGrLLKDYupyFPtmGtau'),
(8, 'asd', 'qwe wqe', 'd@d.dd', '00000000000', '$2y$10$JjNN8kgCOAc9oCnWmtNzku81/8pezPE7mekNv3qzP1KXCEknS9vqu');

-- --------------------------------------------------------

--
-- Estrutura para tabela `desempenho`
--

CREATE TABLE `desempenho` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `nota` int(11) NOT NULL,
  `tentativas` int(11) DEFAULT 1,
  `atualizado_em` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `desempenho`
--

INSERT INTO `desempenho` (`id`, `usuario_id`, `nota`, `tentativas`, `atualizado_em`) VALUES
(1, 6, 5, 1, '2025-06-22 03:41:43');

-- --------------------------------------------------------

--
-- Estrutura para tabela `notas_individuais`
--

CREATE TABLE `notas_individuais` (
  `id` int(11) NOT NULL,
  `aluno_id` int(11) NOT NULL,
  `nota` decimal(5,2) DEFAULT NULL,
  `data_avaliacao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `notas_turma`
--

CREATE TABLE `notas_turma` (
  `id` int(11) NOT NULL,
  `data_avaliacao` datetime DEFAULT current_timestamp(),
  `media_turma` decimal(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pergunta`
--

CREATE TABLE `pergunta` (
  `id` int(11) NOT NULL,
  `texto` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pergunta`
--

INSERT INTO `pergunta` (`id`, `texto`) VALUES
(1, 'Qual dessas é uma senha forte?'),
(2, 'O que é phishing?'),
(3, 'O que fazer ao receber um e-mail suspeito do banco?'),
(4, 'Qual desses comportamentos é mais seguro em uma rede Wi-Fi pública?'),
(5, 'Por que usar a mesma senha em tudo é arriscado?'),
(6, 'O que fazer com atualizações de segurança no celular?'),
(7, 'Qual informação não deve ser pública no seu perfil?'),
(8, 'Como saber se um site é seguro?'),
(9, 'O que é uma VPN?'),
(10, 'Qual a melhor atitude em relação à segurança digital?');

-- --------------------------------------------------------

--
-- Estrutura para tabela `respostas`
--

CREATE TABLE `respostas` (
  `id` int(11) NOT NULL,
  `pergunta_id` int(11) DEFAULT NULL,
  `texto` text NOT NULL,
  `correta` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `respostas`
--

INSERT INTO `respostas` (`id`, `pergunta_id`, `texto`, `correta`) VALUES
(1, 1, 'maria123', 0),
(2, 1, '123456', 0),
(3, 1, 'senha2020', 0),
(4, 1, 'F3r!@2025*', 1),
(5, 2, 'Um vírus de computador', 0),
(6, 2, 'Um golpe que finge ser algo confiável para roubar seus dados', 1),
(7, 2, 'Um firewall', 0),
(8, 2, 'Um tipo de rede segura', 0),
(9, 3, 'Clicar no link imediatamente', 0),
(10, 3, 'Ignorar e reenviar aos amigos', 0),
(11, 3, 'Acessar o site oficial diretamente e verificar', 1),
(12, 3, 'Responder com seus dados', 0),
(13, 4, 'Acessar o aplicativo do banco', 0),
(14, 4, 'Fazer compras online', 0),
(15, 4, 'Usar uma VPN', 1),
(16, 4, 'Digitar suas senhas livremente', 0),
(17, 5, 'Porque é difícil de lembrar', 0),
(18, 5, 'Porque pode travar o celular', 0),
(19, 5, 'Porque, se um site for invadido, todos os outros ficam vulneráveis', 1),
(20, 5, 'Porque economiza tempo', 0),
(21, 6, 'Ignorar, pois são lentas', 0),
(22, 6, 'Deixar para depois', 0),
(23, 6, 'Atualizar sempre que possível', 1),
(24, 6, 'Desinstalar os aplicativos', 0),
(25, 7, 'Nome do cachorro', 0),
(26, 7, 'Nome do colégio', 0),
(27, 7, 'Data de nascimento', 0),
(28, 7, 'Todas as anteriores', 1),
(29, 8, 'Ele tem cores bonitas', 0),
(30, 8, 'O endereço começa com https://', 1),
(31, 8, 'Ele não pede senha', 0),
(32, 8, 'Aparece no Google', 0),
(33, 9, 'Um antivírus', 0),
(34, 9, 'Um tipo de golpe', 0),
(35, 9, 'Uma rede privada virtual que protege seus dados', 1),
(36, 9, 'Um app de fotos', 0),
(37, 10, 'Confiar em qualquer link que parecer bonito', 0),
(38, 10, 'Ser cauteloso e questionar tudo que for suspeito', 1),
(39, 10, 'Compartilhar tudo com seus amigos', 0),
(40, 10, 'Usar senha igual em tudo para facilitar', 0);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `alunos`
--
ALTER TABLE `alunos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_name` (`user_name`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `desempenho`
--
ALTER TABLE `desempenho`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `notas_individuais`
--
ALTER TABLE `notas_individuais`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_aluno` (`aluno_id`);

--
-- Índices de tabela `notas_turma`
--
ALTER TABLE `notas_turma`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `pergunta`
--
ALTER TABLE `pergunta`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `respostas`
--
ALTER TABLE `respostas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pergunta` (`pergunta_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `alunos`
--
ALTER TABLE `alunos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `desempenho`
--
ALTER TABLE `desempenho`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `notas_individuais`
--
ALTER TABLE `notas_individuais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `notas_turma`
--
ALTER TABLE `notas_turma`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pergunta`
--
ALTER TABLE `pergunta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `respostas`
--
ALTER TABLE `respostas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `desempenho`
--
ALTER TABLE `desempenho`
  ADD CONSTRAINT `desempenho_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `alunos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `notas_individuais`
--
ALTER TABLE `notas_individuais`
  ADD CONSTRAINT `fk_aluno` FOREIGN KEY (`aluno_id`) REFERENCES `alunos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `respostas`
--
ALTER TABLE `respostas`
  ADD CONSTRAINT `fk_pergunta` FOREIGN KEY (`pergunta_id`) REFERENCES `pergunta` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
