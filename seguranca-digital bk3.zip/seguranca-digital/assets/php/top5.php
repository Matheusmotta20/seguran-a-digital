<?php
header('Content-Type: application/json');
include_once('conecta.php');

try {
    $stmt = $pdo->prepare("
        SELECT alunos.nome, desempenho.nota, desempenho.tentativas
        FROM desempenho
        INNER JOIN alunos ON alunos.id = desempenho.usuario_id
        ORDER BY desempenho.nota DESC
        LIMIT 5
    ");
    $stmt->execute();
    $top5 = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($top5);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(["erro" => "Erro na consulta: " . $e->getMessage()]);
}
?>
