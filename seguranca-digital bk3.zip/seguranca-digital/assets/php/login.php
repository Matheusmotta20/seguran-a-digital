<?php
session_start();
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

include_once('conecta.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['username'], $data['senha'])) {
    echo json_encode(['success' => false, 'message' => 'Dados incompletos']);
    exit;
}

$username = trim($data['username']);
$senha = trim($data['senha']);

try {
    $stmt = $pdo->prepare("SELECT * FROM alunos WHERE username = :username");
    $stmt->bindParam(":username", $username);
    $stmt->execute();
    $aluno = $stmt->fetch();

    if ($aluno && password_verify($senha, $aluno['senha'])) {
        $_SESSION['usuario_id'] = $aluno['id'];
        $_SESSION['username'] = $aluno['username'];

        echo json_encode([
            'success' => true,
            'message' => 'Login realizado com sucesso',
            'redirect' => '../../index.html'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Usuário ou senha incorretos']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro no servidor']);
}