<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

include_once('conecta.php');

try {
    $sql = "
        SELECT 
            p.id AS pergunta_id, 
            p.texto AS pergunta, 
            r.texto AS resposta, 
            r.correta
        FROM pergunta p
        JOIN respostas r ON r.pergunta_id = p.id
        ORDER BY p.id, r.id
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $dados = [];
    foreach ($rows as $row) {
        $pid = $row['pergunta_id'];
        if (!isset($dados[$pid])) {
            $dados[$pid] = [
                'pergunta' => $row['pergunta'],
                'respostas' => []
            ];
        }
        $dados[$pid]['respostas'][] = [
            'texto' => $row['resposta'],
            'correta' => (int)$row['correta']
        ];
    }

    $result = array_values($dados);
    echo json_encode($result);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao carregar perguntas', 'msg' => $e->getMessage()]);
}