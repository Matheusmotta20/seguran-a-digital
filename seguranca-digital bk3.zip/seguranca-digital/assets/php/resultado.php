<?php
    include("conecta.php");

    $data = json_decode(file_get_contents("php://input"), true);

    $usuario = $data["usuario"];
    $nota = $data["nota"];

    // Etapa 1: Obter a turma do usuário
    $sql_turma = "SELECT id_turma FROM alunos WHERE cadastro_user = ?";
    $stmt = $conn->prepare($sql_turma);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $stmt->bind_result($id_turma);
    $stmt->fetch();
    $stmt->close();

    if (!$id_turma) {
        echo json_encode(["status" => "erro", "msg" => "Turma não encontrada para o usuário."]);
        exit;
    }

    // Etapa 2: Inserir nota individual
    $sql_insert = "INSERT INTO notas_individuais (id, nota, data_resposta)
                VALUES (?, ?, NOW())";
    $stmt = $conn->prepare($sql_insert);
    $stmt->bind_param("si", $usuario, $nota);
    $stmt->execute();
    $stmt->close();

    // Etapa 3: Calcular nova média da turma
    $sql_media = "SELECT AVG(nota) AS media FROM notas_individuais
                WHERE id IN (
                    SELECT id FROM alunos WHERE id_turma = ?
                )";
    $stmt = $conn->prepare($sql_media);
    $stmt->bind_param("i", $id_turma);
    $stmt->execute();
    $stmt->bind_result($media);
    $stmt->fetch();
    $stmt->close();

    if ($media === null) {
        echo json_encode(["status" => "erro", "msg" => "Não foi possível calcular a média."]);
        exit;
    }

    // Etapa 4: Atualizar ou inserir média na tabela notas_turma
    $sql_upsert = "INSERT INTO notas_turma (id_turma, media_turma, data_atualizacao)
                VALUES (?, ?, NOW())
                ON DUPLICATE KEY UPDATE
                    media_turma = VALUES(media_turma),
                    data_atualizacao = NOW()";
    $stmt = $conn->prepare($sql_upsert);
    $stmt->bind_param("id", $id_turma, $media);
    $stmt->execute();

    if ($stmt->affected_rows >= 0) {
        echo json_encode(["status" => "sucesso", "media_turma" => round($media, 2)]);
    } else {
        echo json_encode(["status" => "erro", "msg" => "Erro ao atualizar média da turma."]);
    }

    $stmt->close();
    $conn->close();
?>