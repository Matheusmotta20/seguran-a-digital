<?php
session_start();
header('Content-Type: application/json');
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Usuário não autenticado']);
    exit;
}

// Conexão com o banco (usa seu conecta.php)
include_once('conecta.php');

// Captura e valida os dados recebidos
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['nota'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Nota não informada']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$nota = (int)$input['nota'];

try {
    // Verifica se já existe um registro de desempenho para esse usuário
    $stmt = $pdo->prepare('SELECT id, tentativas FROM desempenho WHERE usuario_id = ?');
    $stmt->execute([$usuario_id]);
    $desempenho = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($desempenho) {
        // Atualiza o registro existente
        $tentativas = $desempenho['tentativas'] + 1;
        $stmt = $pdo->prepare('UPDATE desempenho SET nota = ?, tentativas = ?, atualizado_em = NOW() WHERE id = ?');
        $stmt->execute([$nota, $tentativas, $desempenho['id']]);
    } else {
        // Cria um novo registro de desempenho
        $stmt = $pdo->prepare('INSERT INTO desempenho (usuario_id, nota, tentativas) VALUES (?, ?, 1)');
        $stmt->execute([$usuario_id, $nota]);
    }

    echo json_encode(['success' => true]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro ao acessar banco de dados: ' . $e->getMessage()]);
}