<?php
    // Conexão com o banco de dados
    $host = 'localhost';
    $db = 'cadastro';
    $user = 'root';
    $senha = '';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $senha);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Erro ao conectar ao banco de dados."]);
        exit;
    }
?>