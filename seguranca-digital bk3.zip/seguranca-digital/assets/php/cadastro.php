<?php
    // Cabeçalhos e erros
    header('Content-Type: application/json');
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    // Só POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(["success" => false, "message" => "Método não permitido"]);
        exit;
    }

    // Conexão
    include_once("./conecta.php");

    // Lê JSON enviado
    $data = json_decode(file_get_contents("php://input"), true);

    // Campos obrigatórios
    $campos = ['username', 'nome', 'email', 'telefone', 'senha'];
    foreach ($campos as $campo) {
        if (empty($data[$campo])) {
            echo json_encode(["success" => false, "message" => "Campo '$campo' é obrigatório"]);
            exit;
        }
    }

    // Sanitização
    $username = trim($data['username']);
    $nome     = trim($data['nome']);
    $email    = filter_var(trim($data['email']), FILTER_VALIDATE_EMAIL);
    $telefone = preg_replace('/\D/', '', $data['telefone']);
    $senha    = $data['senha'];

    // Validações
    if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
        echo json_encode(["success" => false, "message" => "Nome de usuário inválido"]);
        exit;
    }

    if (str_word_count($nome) < 2) {
        echo json_encode(["success" => false, "message" => "Digite o nome completo"]);
        exit;
    }

    if (!$email) {
        echo json_encode(["success" => false, "message" => "Email inválido"]);
        exit;
    }

    if (!preg_match('/^\d{10,11}$/', $telefone)) {
        echo json_encode(["success" => false, "message" => "Telefone inválido"]);
        exit;
    }

    if (!preg_match('/^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9]).{8,}$/', $senha)) {
        echo json_encode(["success" => false, "message" => "Senha fraca"]);
        exit;
    }

    try {
        // Verificar duplicidade
        $stmt = $pdo->prepare("SELECT id FROM alunos WHERE username = :username OR email = :email");
        $stmt->execute(['username' => $username, 'email' => $email]);

        if ($stmt->rowCount() > 0) {
            echo json_encode(["success" => false, "message" => "Usuário ou email já cadastrado"]);
            exit;
        }

        // Hash da senha e inserção
        $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("INSERT INTO alunos (username, nome, email, telefone, senha) VALUES (:username, :nome, :email, :telefone, :senha)");
        $stmt->execute([
            'username' => $username,
            'nome' => $nome,
            'email' => $email,
            'telefone' => $telefone,
            'senha' => $senha
        ]);

        echo json_encode(["success" => true, "message" => "Cadastro realizado com sucesso"]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["success" => false, "message" => "Erro no servidor: " . $e->getMessage()]);
    }
?>