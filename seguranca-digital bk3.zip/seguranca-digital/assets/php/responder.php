<?php
    require_once "conecta.php";

    $dados = json_decode(file_get_contents("php://input"), true);

    $id = $dados['id'];
    $pergunta_id = (int)$dados['pergunta_id'];
    $resposta_id = (int)$dados['resposta_id'];

    // Verifica se resposta é correta
    $sql_verifica = "SELECT correta FROM respostas WHERE id = ?";
    $stmt = $conn->prepare($sql_verifica);
    $stmt->bind_param("i", $resposta_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $correta = 0;
    if ($row = $result->fetch_assoc()) {
        $correta = $row['correta'];
    }

    // Insere resposta
    $sql_insere = "INSERT INTO respostas_alunos (id, pergunta_id, resposta_id, correta)
                VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql_insere);
    $stmt->bind_param("siii", $id, $pergunta_id, $resposta_id, $correta);
    $stmt->execute();

    echo json_encode(["sucesso" => true, "correta" => $correta]);
?>