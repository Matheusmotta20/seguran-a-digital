<?php
    session_start();
    session_destroy();
    header("Location: /seguranca-digital/index.html");
    exit;
?>