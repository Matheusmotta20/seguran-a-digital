<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método inválido']);
    exit;
}

$usuario_id = $_SESSION['usuario_id']; // ID do usuário logado
$nota = isset($_POST['nota']) ? intval($_POST['nota']) : null;

if ($nota === null) {
    echo json_encode(['success' => false, 'message' => 'Nota não informada']);
    exit;
}

$servername = "localhost";
$username = "seu_usuario";
$password = "sua_senha";
$dbname = "seu_banco";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verifica se já existe desempenho do usuário
    $stmt = $conn->prepare("SELECT id, tentativas FROM desempenho WHERE usuario_id = :usuario_id");
    $stmt->execute(['usuario_id' => $usuario_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        // Atualiza desempenho e incrementa tentativas
        $stmtUpdate = $conn->prepare("UPDATE desempenho SET nota = :nota, tentativas = tentativas + 1, atualizado_em = NOW() WHERE id = :id");
        $stmtUpdate->execute([
            'nota' => $nota,
            'id' => $row['id']
        ]);
    } else {
        // Insere novo desempenho
        $stmtInsert = $conn->prepare("INSERT INTO desempenho (usuario_id, nota, tentativas) VALUES (:usuario_id, :nota, 1)");
        $stmtInsert->execute([
            'usuario_id' => $usuario_id,
            'nota' => $nota
        ]);
    }

    echo json_encode(['success' => true, 'message' => 'Desempenho salvo com sucesso']);

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro no banco: ' . $e->getMessage()]);
}