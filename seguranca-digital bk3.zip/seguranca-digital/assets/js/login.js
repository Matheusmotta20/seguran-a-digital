// Função para mostrar mensagens no modal
function showMessage(title, message, type = "danger") {
  const modal = new bootstrap.Modal(document.getElementById("messageModal"));
  document.getElementById("messageModalTitle").textContent = title;
  document.getElementById("messageModalBody").textContent = message;
  document.getElementById(
    "messageModalTitle"
  ).className = `modal-title text-${type}`;
  modal.show();
}

// Função para alternar visibilidade da senha
window.togglePassword = function (id) {
  const input = document.getElementById(id);
  if (!input) return;

  const icon = input.nextElementSibling.querySelector("i");
  input.type = input.type === "password" ? "text" : "password";
  icon.classList.toggle("bi-eye-slash");
  icon.classList.toggle("bi-eye");
};

// Função para carregar o status do usuário no nav
async function loadUserStatus() {
  const navUserSection = document.getElementById("nav-user-section");
  if (!navUserSection) return;

  try {
    const response = await fetch("/seguranca-digital/assets/php/user.php", { credentials: "include" });
    const data = await response.json();

    if (data.loggedIn) {
      navUserSection.innerHTML = `
          <div class="dropdown">
            <a class="btn btn-light dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="bi bi-person-circle me-2 fs-5"></i> ${data.username}
            </seguranca-digital/a>
            <ul class="dropdown-menu dropdown-menu-end">
              <li><a class="dropdown-item" href="/seguranca-digital/assets/php/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Sair</seguranca-digital/a></li>
            </ul>
          </div>
        `;
    } else {
      navUserSection.innerHTML = `
          <a href="/seguranca-digital/assets/html/login.html" class="btn btn-outline-light">
            <i class="bi bi-box-arrow-in-right me-1"></i>Login
          </seguranca-digital/a>
          <a href="/seguranca-digital/assets/html/cadastro.html" class="btn btn-light text-primary">
            <i class="bi bi-person-plus me-1"></i>Cadastre-se
          </seguranca-digital/a>
        `;
    }
  } catch (err) {
    console.error("Erro ao verificar status do usuário", err);
    navUserSection.innerHTML = `
        <a href="/seguranca-digital/assets/html/login.html" class="btn btn-outline-light">
          <i class="bi bi-box-arrow-in-right me-1"></i>Login
        </seguranca-digital/a>
        <a href="/seguranca-digital/assets/html/cadastro.html" class="btn btn-light text-primary">
          <i class="bi bi-person-plus me-1"></i>Cadastre-se
        </seguranca-digital/a>
      `;
  }
}

// Quando o DOM estiver carregado
document.addEventListener("DOMContentLoaded", function () {
  // Carrega status do usuário no nav
  loadUserStatus();

  const formLogin = document.getElementById("formLogin");
  if (!formLogin) return;

  const inputUsername = document.getElementById("iUsername");
  const inputSenha = document.getElementById("iSenha");
  const btnSubmit = formLogin.querySelector('button[type="submit"]');

  // Remover erro ao digitar
  [inputUsername, inputSenha].forEach((input) => {
    input.addEventListener("input", function () {
      if (this.value.trim().length > 0) {
        this.classList.remove("is-invalid");
      }
    });
  });

  // Submit do formulário
  formLogin.addEventListener("submit", async function (e) {
    e.preventDefault();

    let formIsValid = true;
    btnSubmit.disabled = true;
    btnSubmit.innerHTML =
      '<span class="spinner-border spinner-border-sm me-2"></span> Entrando...';

    if (!inputUsername.value.trim()) {
      inputUsername.classList.add("is-invalid");
      formIsValid = false;
    }

    if (!inputSenha.value.trim()) {
      inputSenha.classList.add("is-invalid");
      formIsValid = false;
    }

    if (!formIsValid) {
      showMessage("Erro", "Preencha todos os campos corretamente");
      btnSubmit.disabled = false;
      btnSubmit.innerHTML =
        '<i class="bi bi-box-arrow-in-right me-2"></i> Entrar';
      return;
    }

    try {
      const response = await fetch("/seguranca-digital/assets/php/login.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Requested-With": "XMLHttpRequest",
        },
        body: JSON.stringify({
          username: inputUsername.value.trim(),
          senha: inputSenha.value.trim(),
        }),
      });

      const data = await response.json();

      if (data.success) {
        showMessage("Sucesso", data.message, "success");
        setTimeout(() => {
          window.location.href =
            data.redirect || "/seguranca-digital/index.html";
        }, 1500);
      } else {
        showMessage("Erro", data.message || "Credenciais inválidas");
      }
    } catch (error) {
      showMessage("Erro", "Falha na comunicação com o servidor");
      console.error("Erro:", error);
    } finally {
      btnSubmit.disabled = false;
      btnSubmit.innerHTML =
        '<i class="bi bi-box-arrow-in-right me-2"></i> Entrar';
    }
  });

  // Modal de recuperação de senha (se existir)
  const forgotLink = document.querySelector('a[href="#"]');
  if (forgotLink) {
    forgotLink.addEventListener("click", function (e) {
      e.preventDefault();
      const recoveryModal = new bootstrap.Modal(
        document.getElementById("recoveryModal")
      );
      recoveryModal.show();
    });
  }
});
