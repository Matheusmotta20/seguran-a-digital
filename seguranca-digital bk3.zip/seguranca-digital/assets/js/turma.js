// Gráfico de Desempenho da Turma
document.addEventListener('DOMContentLoaded', function() {
  const ctx = document.getElementById('classChart').getContext('2d');
  const classChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['0-60%', '61-70%', '71-80%', '81-90%', '91-100%'],
      datasets: [{
        label: 'Alunos por Faixa',
        data: [2, 3, 5, 8, 3],
        backgroundColor: [
          'rgba(220, 53, 69, 0.7)',
          'rgba(255, 193, 7, 0.7)',
          'rgba(23, 162, 184, 0.7)',
          'rgba(13, 110, 253, 0.7)',
          'rgba(25, 135, 84, 0.7)'
        ],
        borderColor: [
          'rgba(220, 53, 69, 1)',
          'rgba(255, 193, 7, 1)',
          'rgba(23, 162, 184, 1)',
          'rgba(13, 110, 253, 1)',
          'rgba(25, 135, 84, 1)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            stepSize: 1
          }
        }
      }
    }
  });

  // Simular busca de alunos
  document.querySelector('.btn-outline-secondary').addEventListener('click', function() {
    const termo = document.querySelector('input[type="text"]').value;
    alert(`Buscando por: ${termo}`);
  });
});