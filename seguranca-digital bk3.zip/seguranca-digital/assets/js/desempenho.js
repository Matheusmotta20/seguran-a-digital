// Gráfico de Desempenho
document.addEventListener('DOMContentLoaded', function() {
  const ctx = document.getElementById('performanceChart').getContext('2d');
  const performanceChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'],
      datasets: [{
        label: 'Pontuação Média',
        data: [65, 72, 78, 82, 85, 87],
        borderColor: '#0d6efd',
        backgroundColor: 'rgba(13, 110, 253, 0.1)',
        tension: 0.3,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: false,
          min: 50,
          max: 100
        }
      }
    }
  });

  // Simular clique nos botões de detalhes
  document.querySelectorAll('.btn-outline-primary').forEach(btn => {
    btn.addEventListener('click', function() {
      alert('Detalhes da tentativa serão exibidos aqui!');
    });
  });
});

document.addEventListener('DOMContentLoaded', () => {
  fetch('../php/top5.php')
    .then(response => response.json())
    .then(data => {
      const listGroup = document.querySelector('.list-group');
      listGroup.innerHTML = ''; // limpa HTML fixo

      const medalhas = ['bg-warning text-dark', 'bg-secondary', 'bg-danger'];
      const colocacoes = ['1°', '2°', '3°'];

      data.forEach((aluno, index) => {
        const badgeClass = medalhas[index] || 'bg-info';
        const posicao = colocacoes[index] || (index + 1) + '°';

        const item = document.createElement('div');
        item.className = 'list-group-item leaderboard-item' +
                         (index === 0 ? ' first-place' :
                          index === 1 ? ' second-place' :
                          index === 2 ? ' third-place' : '');

        item.innerHTML = `
          <div class="d-flex align-items-center">
            <div class="position-relative me-3">
              <img src="https://randomuser.me/api/portraits/lego/${index + 1}.jpg" class="avatar">
              <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill ${badgeClass}">
                ${posicao}
              </span>
            </div>
            <div class="flex-grow-1">
              <div class="d-flex justify-content-between">
                <strong>${aluno.nome}</strong>
                <span class="badge bg-success">${aluno.nota * 10}%</span>
              </div>
              <small class="text-muted">${aluno.tentativas} tentativa(s)</small>
            </div>
          </div>
        `;

        listGroup.appendChild(item);
      });
    })
    .catch(error => {
      console.error('Erro ao carregar Top 5:', error);
    });
});
