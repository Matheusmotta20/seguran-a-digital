document.addEventListener("DOMContentLoaded", function () {
  // Configuração AJAX
  const configAjax = {
    url: "../php/cadastro.php",
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Requested-With": "XMLHttpRequest",
    },
  };

  // Elementos do DOM
  const form = document.querySelector("form");
  const inputs = {
    username: document.getElementById("iUsername"),
    nome: document.getElementById("iNomeCompleto"),
    email: document.getElementById("iEmail"),
    telefone: document.getElementById("iTel"),
    senha: document.getElementById("iSenha"),
    confirmaSenha: document.getElementById("iConfirmaSenha"),
    termos: document.getElementById("iTermos"),
  };

  // Modal de mensagem
  const messageModal = new bootstrap.Modal(
    document.getElementById("messageModal")
  );
  const messageTitle = document.getElementById("messageModalTitle");
  const messageBody = document.getElementById("messageModalBody");

  // Funções de validação
  const validacoes = {
    username: (value) => /^[a-zA-Z0-9_]{3,20}$/.test(value),
    nome: (value) =>
      /^[a-zA-ZÀ-ú\s']{5,}$/.test(value) && value.trim().split(" ").length >= 2,
    email: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
    telefone: (value) => /^\(?\d{2}\)?[\s-]?\d{4,5}[\s-]?\d{4}$/.test(value),
    senha: (value) => /^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9]).{8,}$/.test(value),
    confirmaSenha: (value) => value === inputs.senha.value,
    termos: (checked) => checked,
  };

  // Mensagens de erro
  const mensagensErro = {
    username: "3-20 caracteres (letras, números e _)",
    nome: "Nome completo (mínimo 2 palavras)",
    email: "Digite um email válido",
    telefone: "Formato: (00) 00000-0000",
    senha: "8+ caracteres com maiúscula, número e símbolo",
    confirmaSenha: "As senhas não coincidem",
    termos: "Você deve aceitar os termos",
  };

  // Formatar telefone
  inputs.telefone.addEventListener("input", function (e) {
    let value = this.value.replace(/\D/g, "");
    if (value.length > 2)
      value = `(${value.substring(0, 2)}) ${value.substring(2)}`;
    if (value.length > 10)
      value = `${value.substring(0, 10)}-${value.substring(10, 14)}`;
    this.value = value;
  });

  // Toggle password
  window.togglePassword = function (id) {
    const input = document.getElementById(id);
    const icon = input.nextElementSibling.querySelector("i");
    if (input.type === "password") {
      input.type = "text";
      icon.classList.replace("bi-eye-slash", "bi-eye");
    } else {
      input.type = "password";
      icon.classList.replace("bi-eye", "bi-eye-slash");
    }
  };

  // Validar em tempo real
  Object.keys(inputs).forEach((key) => {
    if (inputs[key].type !== "checkbox") {
      inputs[key].addEventListener("input", function () {
        validarCampo(key, this.value);
        if (key === "senha") atualizarForcaSenha(this.value);
        if (key === "senha" && inputs.confirmaSenha.value)
          validarCampo("confirmaSenha", inputs.confirmaSenha.value);
      });
    } else {
      inputs[key].addEventListener("change", function () {
        validarCampo(key, this.checked);
      });
    }
  });

  // Submit do cadastro
  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    let formValido = true;

    // Validar todos os campos
    Object.keys(inputs).forEach((key) => {
      const value =
        inputs[key].type === "checkbox"
          ? inputs[key].checked
          : inputs[key].value;
      if (!validarCampo(key, value)) formValido = false;
    });

    if (formValido) {
      const dados = {
        username: inputs.username.value,
        nome: inputs.nome.value,
        email: inputs.email.value,
        telefone: inputs.telefone.value.replace(/\D/g, ""),
        senha: inputs.senha.value,
      };

      try {
        // Simulação de AJAX (substitua pelo real)
        const response = await enviarDados(dados);
        showMessage(
          "Sucesso",
          "Cadastro realizado com sucesso! Redirecionando...",
          "success"
        );
        setTimeout(() => {
          window.location.href = "../html/login.html"; // ou "login.php", conforme sua estrutura
        }, 2000); // 2 segundos de espera antes de redirecionar
      } catch (error) {
        showMessage("Erro", error.message, "danger");
      }
    } else {
      showMessage(
        "cadastro inválido",
        "Corrija os campos destacados",
        "warning"
      );
    }
  });

  // Funções auxiliares
  function validarCampo(campo, valor) {
    const valido = validacoes[campo](valor);
    if (valido) {
      inputs[campo].classList.remove("is-invalid");
      return true;
    } else {
      inputs[campo].classList.add("is-invalid");
      if (
        inputs[campo].nextElementSibling &&
        inputs[campo].nextElementSibling.classList.contains("invalid-feedback")
      ) {
        inputs[campo].nextElementSibling.textContent = mensagensErro[campo];
      }
      return false;
    }
  }

  function atualizarForcaSenha(senha) {
    let strength = 0;
    if (senha.length >= 8) strength++;
    if (/[A-Z]/.test(senha)) strength++;
    if (/[0-9]/.test(senha)) strength++;
    if (/[^A-Za-z0-9]/.test(senha)) strength++;

    const strengthElement = document.getElementById("senhaStrength");
    const classes = ["bg-danger", "bg-warning", "bg-info", "bg-success"];
    const texts = ["Fraca", "Moderada", "Forte", "Muito Forte"];

    strengthElement.className = `badge ${classes[strength - 1]}`;
    strengthElement.textContent = texts[strength - 1];
  }

  async function enviarDados(dados) {
    //console.log(dados);

    // Implementação real do AJAX
    return new Promise((resolve, reject) => {
      fetch(configAjax.url, {
        method: configAjax.method,
        headers: configAjax.headers,
        body: JSON.stringify(dados),
      })
        .then((response) => response.json())
        .then((data) => { 
          if (data.success) {
            resolve(data);
          } else {
            reject(new Error(data.message || "Erro no cadastro"));
          }
        })
        .catch((error) => reject(error));
    });

  }

  function showMessage(title, message, type) {
    messageTitle.textContent = title;
    messageBody.textContent = message;
    messageTitle.className = `modal-title text-${type}`;
    messageModal.show();
  }
});
