let perguntas = [];
let perguntaAtual = 0;
let pontuacao = 0;

const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");
const progressBar = document.querySelector(".progress-bar");

async function initQuiz() {
  try {
    const response = await fetch("/seguranca-digital/assets/php/quiz.php", {
      credentials: "include",
    });
    const data = await response.json();

    if (!Array.isArray(data) || data.length === 0) {
      questionElement.textContent = "Erro ao carregar perguntas.";
      return;
    }

    perguntas = data;
    startQuiz();
  } catch (error) {
    console.error("Erro ao carregar perguntas:", error);
    questionElement.textContent = "Erro ao carregar perguntas.";
  }
}

function startQuiz() {
  perguntaAtual = 0;
  pontuacao = 0;
  nextButton.innerHTML = "Próxima <i class='bi bi-arrow-right ms-2'></i>";
  nextButton.onclick = handleNextButton;
  mostrarPergunta();
}

function mostrarPergunta() {
  resetarEstado();

  const p = perguntas[perguntaAtual];
  questionElement.innerText = `(${perguntaAtual + 1}/${perguntas.length}) ${
    p.pergunta
  }`;

  p.respostas.forEach((res) => {
    const button = document.createElement("button");
    button.innerText = res.texto;
    button.classList.add("btn-answer");
    button.dataset.correta = res.correta;
    button.addEventListener("click", selecionarResposta);
    answerButtons.appendChild(button);
  });

  atualizarBarraProgresso();
}

function resetarEstado() {
  nextButton.style.display = "none";
  answerButtons.innerHTML = "";
}

function selecionarResposta(e) {
  const btn = e.target;
  const correta = btn.dataset.correta === "1" || btn.dataset.correta === "true";

  Array.from(answerButtons.children).forEach((b) => {
    b.disabled = true;
    const ehCorreta = b.dataset.correta === "1" || b.dataset.correta === "true";

    if (b === btn) {
      if (ehCorreta) {
        b.classList.add("correct");
      } else {
        b.classList.add("incorrect");
      }
    } else if (ehCorreta) {
      b.classList.add("correct");
    }
  });

  if (correta) pontuacao++;
  nextButton.style.display = "inline-block";
}

function handleNextButton() {
  perguntaAtual++;
  if (perguntaAtual < perguntas.length) {
    mostrarPergunta();
  } else {
    mostrarResultado();
  }
}

function mostrarResultado() {
  resetarEstado();
  questionElement.innerHTML = `Você acertou <strong>${pontuacao}</strong> de <strong>${perguntas.length}</strong> perguntas.`;
  progressBar.style.width = "100%";
  nextButton.innerHTML = "Reiniciar <i class='bi bi-arrow-clockwise ms-2'></i>";
  nextButton.style.display = "inline-block";
  nextButton.onclick = startQuiz;

  registrarTentativa(pontuacao);
}

function atualizarBarraProgresso() {
  const progresso = (perguntaAtual / perguntas.length) * 100;
  progressBar.style.width = `${progresso}%`;
}

async function registrarTentativa(nota) {
  try {
    const response = await fetch(
      "/seguranca-digital/assets/php/registrar_tentativa.php",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ nota }),
      }
    );

    if (response.status === 401) {
      alert("Você precisa estar logado para salvar o desempenho.");
      return;
    }

    const data = await response.json();

    if (!data.success) {
      console.error("Erro ao salvar desempenho:", data.error || "Desconhecido");
    }
  } catch (error) {
    console.error("Erro ao registrar tentativa:", error);
  }
}

document.addEventListener("DOMContentLoaded", initQuiz);
